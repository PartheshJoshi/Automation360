package Files;

public class resources {

	public static String placepostdata()
	{
		String resource = "/maps/api/place/add/json";
		return resource;
	}
	public static String placepostdatainxml()
	{
		String xmlresource = "/maps/api/place/add/xml";
		return xmlresource;
	}
}

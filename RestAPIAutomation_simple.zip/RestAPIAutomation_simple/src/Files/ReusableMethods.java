package Files;

import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class ReusableMethods {

	public static XmlPath RawtoXML(Response res)
	{
		
		String response = res.asString();
		XmlPath xpath = new XmlPath(response);
		return xpath;
		
	}
	
	public static JsonPath RawtoJson(Response res)
	{
		
		String response = res.asString();
		JsonPath jpath = new JsonPath(response);
		return jpath;
		
	}
	
}
